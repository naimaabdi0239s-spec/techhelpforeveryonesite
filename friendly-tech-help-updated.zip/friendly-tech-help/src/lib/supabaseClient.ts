import { createClient } from "@supabase/supabase-js";

// These come from your Supabase project (Project Settings -> API) and are
// injected at build time by Vite. Set them in a local `.env` file for
// development (see `.env.example`) and in your host's environment variable
// settings for production/preview deploys.
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

if (!isSupabaseConfigured && import.meta.env.DEV) {
  // Loud but non-fatal: forms fall back to a friendly "not configured" state
  // instead of the whole app crashing when the keys are missing.
  console.warn(
    "[supabase] VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY are not set. " +
      "Database-backed features (question form, reviews) will show a setup notice " +
      "until they're configured. See .env.example.",
  );
}

// Falls back to a harmless placeholder so `createClient` never throws when the
// env vars are missing — callers should check `isSupabaseConfigured` before
// relying on real data.
export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder-anon-key",
);

export type QuestionRow = {
  id: string;
  created_at: string;
  name: string;
  email: string;
  message: string;
};

export type ReviewRow = {
  id: string;
  created_at: string;
  name: string;
  rating: number;
  message: string;
  approved: boolean;
};
