import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CheckCircle2, LogOut, Star, Trash2, XCircle } from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import {
  supabase,
  isSupabaseConfigured,
  type QuestionRow,
  type ReviewRow,
} from "@/lib/supabaseClient";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

const NAVY = "#000080";
const BLUE = "#08AECC";
const RED = "#FF0000";

function NotConfigured() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#eef6ff] px-4">
      <div className="max-w-md text-center bg-white rounded-2xl p-8 border border-[color:var(--border)]">
        <h1 className="text-xl font-semibold" style={{ color: NAVY }}>
          Admin dashboard isn't connected yet
        </h1>
        <p className="mt-2 text-sm text-[color:var(--muted-foreground)]">
          Add <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_ANON_KEY</code> to your
          environment, then reload this page. See <code>.env.example</code> in the project root.
        </p>
      </div>
    </div>
  );
}

function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) setError(error.message);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#eef6ff] px-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-white rounded-2xl p-8 border border-[color:var(--border)] space-y-4"
      >
        <div>
          <h1 className="text-xl font-semibold" style={{ color: NAVY }}>
            Admin sign in
          </h1>
          <p className="mt-1 text-sm text-[color:var(--muted-foreground)]">
            Sign in to review and approve testimonials.
          </p>
        </div>
        <div>
          <label className="text-xs font-medium" style={{ color: NAVY }}>
            Email
          </label>
          <input
            type="email"
            required
            autoComplete="username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-lg border border-[color:var(--border)] px-3 py-2 text-sm outline-none focus:border-[color:var(--accent)]"
          />
        </div>
        <div>
          <label className="text-xs font-medium" style={{ color: NAVY }}>
            Password
          </label>
          <input
            type="password"
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-lg border border-[color:var(--border)] px-3 py-2 text-sm outline-none focus:border-[color:var(--accent)]"
          />
        </div>
        {error && (
          <p className="text-xs" style={{ color: RED }}>
            {error}
          </p>
        )}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-60"
          style={{ background: RED }}
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
    </div>
  );
}

function StarRow({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <Star
          key={n}
          className="w-3.5 h-3.5"
          fill={n <= rating ? "currentColor" : "none"}
          style={{ color: n <= rating ? BLUE : `${NAVY}30` }}
        />
      ))}
    </div>
  );
}

function Dashboard() {
  const [reviews, setReviews] = useState<ReviewRow[]>([]);
  const [questions, setQuestions] = useState<QuestionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  async function loadData() {
    setLoading(true);
    const [reviewsRes, questionsRes] = await Promise.all([
      supabase.from("reviews").select("*").order("created_at", { ascending: false }),
      supabase.from("questions").select("*").order("created_at", { ascending: false }),
    ]);
    if (reviewsRes.error) setErrorMsg(reviewsRes.error.message);
    else if (questionsRes.error) setErrorMsg(questionsRes.error.message);
    else setErrorMsg("");
    setReviews(reviewsRes.data ?? []);
    setQuestions(questionsRes.data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    loadData();
  }, []);

  async function setApproved(id: string, approved: boolean) {
    await supabase.from("reviews").update({ approved }).eq("id", id);
    loadData();
  }

  async function deleteReview(id: string) {
    await supabase.from("reviews").delete().eq("id", id);
    loadData();
  }

  async function deleteQuestion(id: string) {
    await supabase.from("questions").delete().eq("id", id);
    loadData();
  }

  const pending = reviews.filter((r) => !r.approved);
  const approved = reviews.filter((r) => r.approved);

  return (
    <div className="min-h-screen bg-[#eef6ff]">
      <header className="border-b border-[color:var(--border)] bg-white">
        <div className="mx-auto max-w-5xl px-5 h-16 flex items-center justify-between">
          <div className="font-semibold" style={{ color: NAVY }}>
            Reviews & questions admin
          </div>
          <button
            onClick={() => supabase.auth.signOut()}
            className="inline-flex items-center gap-1.5 text-sm font-medium"
            style={{ color: NAVY }}
          >
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-10 space-y-12">
        {errorMsg && (
          <p className="text-sm" style={{ color: RED }}>
            {errorMsg}
          </p>
        )}

        <section>
          <h2 className="text-lg font-semibold" style={{ color: NAVY }}>
            Pending reviews
            {pending.length > 0 && (
              <span className="ml-1 text-sm font-normal opacity-60">({pending.length})</span>
            )}
          </h2>
          {loading ? (
            <p className="mt-3 text-sm opacity-60">Loading…</p>
          ) : pending.length === 0 ? (
            <p className="mt-3 text-sm text-[color:var(--muted-foreground)]">
              No reviews waiting for approval.
            </p>
          ) : (
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {pending.map((r) => (
                <div
                  key={r.id}
                  className="rounded-xl bg-white p-4 border border-[color:var(--border)]"
                >
                  <div className="flex items-center justify-between">
                    <div className="font-semibold text-sm" style={{ color: NAVY }}>
                      {r.name || "Anonymous"}
                    </div>
                    <StarRow rating={r.rating} />
                  </div>
                  <p className="mt-2 text-[13.5px] text-[color:var(--muted-foreground)] leading-relaxed">
                    {r.message}
                  </p>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setApproved(r.id, true)}
                      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold text-white"
                      style={{ background: NAVY }}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                    </button>
                    <button
                      onClick={() => deleteReview(r.id)}
                      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold border"
                      style={{ borderColor: `${RED}55`, color: RED }}
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section>
          <h2 className="text-lg font-semibold" style={{ color: NAVY }}>
            Approved / published reviews
          </h2>
          {approved.length === 0 ? (
            <p className="mt-3 text-sm text-[color:var(--muted-foreground)]">
              Nothing published yet.
            </p>
          ) : (
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {approved.map((r) => (
                <div
                  key={r.id}
                  className="rounded-xl bg-white p-4 border border-[color:var(--border)]"
                >
                  <div className="flex items-center justify-between">
                    <div className="font-semibold text-sm" style={{ color: NAVY }}>
                      {r.name || "Anonymous"}
                    </div>
                    <StarRow rating={r.rating} />
                  </div>
                  <p className="mt-2 text-[13.5px] text-[color:var(--muted-foreground)] leading-relaxed">
                    {r.message}
                  </p>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() => setApproved(r.id, false)}
                      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold border"
                      style={{ borderColor: `${NAVY}40`, color: NAVY }}
                    >
                      <XCircle className="w-3.5 h-3.5" /> Unpublish
                    </button>
                    <button
                      onClick={() => deleteReview(r.id)}
                      className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold border"
                      style={{ borderColor: `${RED}55`, color: RED }}
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section>
          <h2 className="text-lg font-semibold" style={{ color: NAVY }}>
            Submitted questions
            {questions.length > 0 && (
              <span className="ml-1 text-sm font-normal opacity-60">({questions.length})</span>
            )}
          </h2>
          {questions.length === 0 ? (
            <p className="mt-3 text-sm text-[color:var(--muted-foreground)]">
              No questions submitted yet.
            </p>
          ) : (
            <div className="mt-4 space-y-3">
              {questions.map((q) => (
                <div
                  key={q.id}
                  className="rounded-xl bg-white p-4 border border-[color:var(--border)]"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="font-semibold text-sm" style={{ color: NAVY }}>
                        {q.name}
                      </div>
                      <a href={`mailto:${q.email}`} className="text-xs" style={{ color: BLUE }}>
                        {q.email}
                      </a>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs opacity-50">
                        {new Date(q.created_at).toLocaleString()}
                      </span>
                      <button
                        onClick={() => deleteQuestion(q.id)}
                        className="text-xs font-semibold"
                        style={{ color: RED }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  <p className="mt-2 text-[13.5px] text-[color:var(--muted-foreground)] leading-relaxed">
                    {q.message}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function AdminPage() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!isSupabaseConfigured) return <NotConfigured />;
  if (session === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#eef6ff] text-sm opacity-60">
        Loading…
      </div>
    );
  }
  if (!session) return <LoginForm />;
  return <Dashboard />;
}
