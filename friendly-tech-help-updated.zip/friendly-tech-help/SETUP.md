# Setup guide — Supabase + admin dashboard

This adds a working database to the "Ask a question" form and the review
system, plus an admin dashboard where Tobias can approve reviews before
they go live. Everything is coded and tested — you just need to connect it
to a real Supabase project (I can't create one on your behalf).

## 1. Create a Supabase project

1. Go to https://supabase.com and sign up / log in.
2. Click **New project**. Pick any name/region, set a database password
   (save it somewhere safe), and wait ~2 minutes for it to spin up.

## 2. Create the tables

1. In your new project, open **SQL Editor** (left sidebar) → **New query**.
2. Open `supabase/schema.sql` from this project, copy the whole file, paste
   it in, and click **Run**.
3. This creates two tables — `questions` and `reviews` — with security rules
   already set up so:
   - Anyone can submit a question or a review from the public site.
   - Only a signed-in admin can read submitted questions.
   - Site visitors only ever see reviews that have been approved.
   - Only a signed-in admin can approve, unpublish, or delete a review.

## 3. Get your API keys

1. In Supabase: **Project Settings** (gear icon) → **API**.
2. Copy the **Project URL** and the **anon public** key.

## 4. Add the keys to the project

**Local development:**
```
cp .env.example .env
```
then paste your values into `.env`:
```
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

**If you're deploying through Lovable:** add the same two variables under
your project's **Environment Variables** settings in Lovable instead (or in
addition, for local dev).

## 5. Create Tobias's admin login

The `/admin` page uses Supabase's own login system — no separate password
to manage. Do **not** turn on public sign-ups for this project; the SQL
policies treat *any* signed-in user as an admin, so the only account that
should exist is Tobias's.

1. In Supabase: **Authentication** → **Users** → **Add user**.
2. Enter Tobias's email and a password, and make sure "Auto Confirm User"
   is checked (so he doesn't need to click an email link).
3. He can now go to `yoursite.com/admin` and sign in with that email/password
   to approve or unpublish reviews, and to read submitted questions.

## What's live once this is connected

- **Ask a question** (on the homepage, `#ask` section) → saves to the
  `questions` table. Tobias sees these on `/admin`.
- **Leave a review** (Testimonials section) → saves to `reviews` with
  `approved = false`. It won't show publicly until Tobias approves it
  from `/admin`.
- **Approved reviews** automatically appear next to the review form on the
  homepage, newest first.

## A couple of things worth double-checking yourself

- **Instagram link**: the footer link now points to
  `instagram.com/techsupportforeveryone` to match the handle already shown
  on the site — I couldn't verify that account actually exists/is correct,
  so please confirm the handle is right (or send me the correct one).
- **Sending actual emails** (e.g. an email notification to
  Techsupportforeveryone@gmail.com whenever someone submits a question) isn't
  set up yet — that needs a transactional email provider (like Resend) and a
  small server-side function. Happy to wire that up too if you want it; just
  let me know and, if you have one, share (or create) an email-provider API
  key.
