-- Run this once in your Supabase project's SQL editor:
-- Dashboard -> SQL Editor -> New query -> paste this whole file -> Run.
--
-- Creates two tables:
--   1. questions  — submissions from the "Ask a question" form
--   2. reviews    — submissions from the "Leave a review" form, held for
--                   approval before they're shown publicly
--
-- Row Level Security (RLS) is turned on for both, so:
--   - Anyone (including anonymous site visitors) can submit a question or a review
--   - Only a signed-in admin (Tobias) can read submitted questions
--   - Site visitors can only ever read reviews that have been approved
--   - Only a signed-in admin can approve/reject/delete reviews
--
-- IMPORTANT: don't turn on public sign-ups for this project. Create the
-- admin login for Tobias directly in Dashboard -> Authentication -> Users ->
-- Add user, with his email + a password. That's the only account that should
-- exist, since any signed-in ("authenticated") user is treated as an admin
-- below.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- questions
-- ---------------------------------------------------------------------------
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  message text not null
);

alter table public.questions enable row level security;

drop policy if exists "Anyone can submit a question" on public.questions;
create policy "Anyone can submit a question"
  on public.questions
  for insert
  to anon, authenticated
  with check (true);

drop policy if exists "Admins can read questions" on public.questions;
create policy "Admins can read questions"
  on public.questions
  for select
  to authenticated
  using (true);

drop policy if exists "Admins can delete questions" on public.questions;
create policy "Admins can delete questions"
  on public.questions
  for delete
  to authenticated
  using (true);

-- ---------------------------------------------------------------------------
-- reviews
-- ---------------------------------------------------------------------------
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  rating smallint not null check (rating between 1 and 5),
  message text not null,
  approved boolean not null default false
);

alter table public.reviews enable row level security;

-- New reviews always start as unapproved, no matter what a client sends.
drop policy if exists "Anyone can submit a review" on public.reviews;
create policy "Anyone can submit a review"
  on public.reviews
  for insert
  to anon, authenticated
  with check (approved = false);

drop policy if exists "Anyone can read approved reviews" on public.reviews;
create policy "Anyone can read approved reviews"
  on public.reviews
  for select
  to anon, authenticated
  using (approved = true);

drop policy if exists "Admins can read all reviews" on public.reviews;
create policy "Admins can read all reviews"
  on public.reviews
  for select
  to authenticated
  using (true);

drop policy if exists "Admins can update reviews" on public.reviews;
create policy "Admins can update reviews"
  on public.reviews
  for update
  to authenticated
  using (true)
  with check (true);

drop policy if exists "Admins can delete reviews" on public.reviews;
create policy "Admins can delete reviews"
  on public.reviews
  for delete
  to authenticated
  using (true);

-- Helpful for the admin dashboard's default sort order.
create index if not exists reviews_created_at_idx on public.reviews (created_at desc);
create index if not exists questions_created_at_idx on public.questions (created_at desc);
